/**
 * APEX TRADER SERVER
 * 24/7 autonomous trading agent
 * Runs Claude AI analysis, places Alpaca orders, sends email alerts
 */

require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const nodemailer = require('nodemailer');
const cron = require('node-cron');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// ─── Config ───────────────────────────────────────────────
const CONFIG = {
  anthropicKey: process.env.ANTHROPIC_API_KEY,
  alpacaKey: process.env.ALPACA_API_KEY,
  alpacaSecret: process.env.ALPACA_API_SECRET,
  alpacaMode: process.env.ALPACA_MODE || 'paper',
  emailFrom: process.env.EMAIL_FROM,
  emailPassword: process.env.EMAIL_PASSWORD,
  emailTo: process.env.EMAIL_TO,
  maxRiskPct: parseFloat(process.env.MAX_RISK_PER_TRADE) || 1.5,
  dailyLossLimit: parseFloat(process.env.DAILY_LOSS_LIMIT) || 500,
  maxPositions: parseInt(process.env.MAX_OPEN_POSITIONS) || 3,
  minConfidence: parseInt(process.env.MIN_CONFIDENCE) || 6,
  scanIntervalMins: parseInt(process.env.SCAN_INTERVAL_MINUTES) || 5,
  port: parseInt(process.env.PORT) || 3000,
};

const ALPACA_BASE = CONFIG.alpacaMode === 'live'
  ? 'https://api.alpaca.markets'
  : 'https://paper-api.alpaca.markets';
const ALPACA_DATA = 'https://data.alpaca.markets';

// ─── State (persisted to disk) ────────────────────────────
const STATE_FILE = path.join(__dirname, 'state.json');

let state = {
  memories: [],
  lessons: [],
  trades: [],
  stratStats: {
    Momentum: { w: 0, l: 0, pnl: 0 },
    'Mean Reversion': { w: 0, l: 0, pnl: 0 },
    Breakout: { w: 0, l: 0, pnl: 0 },
  },
  confBuckets: [
    { label: '1-4', s: 0, w: 0 },
    { label: '5-6', s: 0, w: 0 },
    { label: '7-8', s: 0, w: 0 },
    { label: '9-10', s: 0, w: 0 },
  ],
  dailyLoss: 0,
  totalPnl: 0,
  wins: 0,
  losses: 0,
  isRunning: false,
  lastScanTime: null,
  agentIQ: 50,
  lastResetDate: new Date().toDateString(),
};

// Expert knowledge - injected into every prompt
const EXPERT_KNOWLEDGE = `
TECHNICAL PRINCIPLES:
- VWAP anchor: Price above VWAP = bullish. Below = bearish. Never long below VWAP in downtrend without strong reversal.
- RSI divergence: Price new highs + RSI fails = reversal. New lows + RSI rises = bounce. Strongest signal.
- Volume confirms moves: Breakout without 1.5x+ avg volume is suspect. High vol = conviction. Low vol = fade.
- Support becomes resistance: Old support flips to resistance when broken. Trade these flip zones.
- First 15 min rule: Wait for initial range to form after open. Most volatile, emotion-driven period.
- ATR sizing: Stop = 1-1.5x ATR from entry. Gives trade room to breathe.
- Risk/reward minimum: Never take <1:2 RR. At 40% win rate you're profitable at 1:2.
- Power hour: Last hour (3-4pm ET) = high volume, accelerated moves. Bigger risk and reward.

FUNDAMENTAL PRINCIPLES:
- Earnings drift (PEAD): Stocks beating estimates 10%+ drift higher for days. Trade the drift.
- News = surprise: Stocks move on surprise not known news. If priced in, reaction may reverse.
- Short squeeze fuel: High short interest (>20% float) + catalyst = explosive upside. Know the float.
- Institutional footprints: High vol with no news = smart money accumulating or distributing.
- Relative strength: Stocks holding green in down market = RS. First to recover when market turns.
- 52-week highs: No overhead resistance = price discovery. Clean momentum trades with volume.
- Float matters: Small float (<20M shares) moves faster and further. Match strategy to float.
- Risk-off check: VIX>25 = reduce all sizes 50%. The tide affects all boats.
`;

// Watchlist - scanned repeatedly
const WATCHLIST = [
  'AAPL', 'MSFT', 'NVDA', 'TSLA', 'META',
  'SPY', 'QQQ', 'IWM', 'AMD', 'AMZN',
  'PLTR', 'CRWD', 'NET', 'COIN', 'JPM',
];

// ─── Persist state ────────────────────────────────────────
function saveState() {
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  } catch (e) {
    console.error('Failed to save state:', e.message);
  }
}

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const saved = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      state = { ...state, ...saved };
      console.log(`✓ Loaded state: ${state.memories.length} memories, ${state.trades.length} trades, IQ ${state.agentIQ}`);
    }
  } catch (e) {
    console.error('Failed to load state:', e.message);
  }
}

// ─── Daily reset (P&L tracking only, keep memory) ─────────
function checkDailyReset() {
  const today = new Date().toDateString();
  if (state.lastResetDate !== today) {
    state.dailyLoss = 0;
    state.lastResetDate = today;
    saveState();
    console.log('📅 Daily P&L reset for', today);
    sendEmail(
      '📅 APEX Trader — New Trading Day',
      `Good morning! A new trading day has started.\n\nAgent IQ: ${state.agentIQ}\nMemories: ${state.memories.length}\nLessons: ${state.lessons.length}\n\nThe agent is ready to scan and trade.`
    );
  }
}

// ─── Email alerts ─────────────────────────────────────────
const emailTransporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: CONFIG.emailFrom,
    pass: CONFIG.emailPassword,
  },
});

async function sendEmail(subject, body) {
  if (!CONFIG.emailFrom || !CONFIG.emailPassword || !CONFIG.emailTo) {
    console.log('Email not configured — skipping:', subject);
    return;
  }
  try {
    await emailTransporter.sendMail({
      from: `APEX Trader <${CONFIG.emailFrom}>`,
      to: CONFIG.emailTo,
      subject,
      html: `
        <div style="font-family:monospace;background:#07080b;color:#dde2f0;padding:24px;border-radius:8px;max-width:500px">
          <div style="color:#00e5b0;font-size:16px;font-weight:bold;margin-bottom:16px">◈ APEX TRADER</div>
          <pre style="white-space:pre-wrap;font-size:14px;line-height:1.7;color:#dde2f0">${body}</pre>
          <div style="margin-top:16px;font-size:11px;color:#424d6a">
            Mode: ${CONFIG.alpacaMode.toUpperCase()} · IQ: ${state.agentIQ} · Memories: ${state.memories.length}
          </div>
        </div>
      `,
    });
    console.log('📧 Email sent:', subject);
  } catch (e) {
    console.error('Email failed:', e.message);
  }
}

// ─── Alpaca API ───────────────────────────────────────────
async function alpacaGet(path) {
  const resp = await fetch(ALPACA_BASE + path, {
    headers: {
      'APCA-API-KEY-ID': CONFIG.alpacaKey,
      'APCA-API-SECRET-KEY': CONFIG.alpacaSecret,
    },
  });
  if (!resp.ok) throw new Error(`Alpaca ${path}: HTTP ${resp.status}`);
  return resp.json();
}

async function alpacaPost(path, body) {
  const resp = await fetch(ALPACA_BASE + path, {
    method: 'POST',
    headers: {
      'APCA-API-KEY-ID': CONFIG.alpacaKey,
      'APCA-API-SECRET-KEY': CONFIG.alpacaSecret,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  const text = await resp.text();
  if (!resp.ok) throw new Error(`Alpaca POST ${path}: ${text}`);
  return JSON.parse(text);
}

async function getAccount() {
  return alpacaGet('/v2/account');
}

async function getPositions() {
  return alpacaGet('/v2/positions');
}

async function getMarketData(ticker) {
  try {
    const end = new Date().toISOString();
    const start = new Date(Date.now() - 3600000 * 2).toISOString();
    const resp = await fetch(
      `${ALPACA_DATA}/v2/stocks/${ticker}/bars?timeframe=5Min&start=${start}&end=${end}&limit=30`,
      {
        headers: {
          'APCA-API-KEY-ID': CONFIG.alpacaKey,
          'APCA-API-SECRET-KEY': CONFIG.alpacaSecret,
        },
      }
    );
    if (!resp.ok) return null;
    const data = await resp.json();
    const bars = data.bars;
    if (!bars || bars.length < 2) return null;

    const latest = bars[bars.length - 1];
    const prev = bars[bars.length - 2];
    const price = +latest.c.toFixed(2);
    const change = +(price - prev.c).toFixed(2);
    const changePct = +((change / prev.c) * 100).toFixed(2);
    const vwap = +(latest.vw || price).toFixed(2);
    const vol = latest.v || 0;

    // Calculate RSI from recent closes
    const closes = bars.map(b => b.c);
    const rsi = calcRSI(closes, 14);
    const atr = +(price * 0.015).toFixed(2);
    const macd = change > 0 ? 0.5 : -0.5;
    const volRatio = +(vol / 1000000).toFixed(2);
    const trend = changePct > 0.6 ? 'uptrend' : changePct < -0.6 ? 'downtrend' : 'sideways';

    return { ticker, price, change, changePct, rsi, vwap, vol, atr, macd, volRatio, trend };
  } catch (e) {
    console.error(`Market data error for ${ticker}:`, e.message);
    return null;
  }
}

function calcRSI(closes, period = 14) {
  if (closes.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) gains += d;
    else losses += Math.abs(d);
  }
  const rs = (gains / period) / (losses / period || 0.001);
  return +(100 - 100 / (1 + rs)).toFixed(1);
}

// ─── Regime detection ─────────────────────────────────────
function detectRegime(m) {
  if (m.volRatio > 1.5 && Math.abs(m.changePct) > 1.8)
    return { regime: 'volatile', strategy: 'Breakout' };
  if (m.trend !== 'sideways' && m.volRatio > 0.9 && Math.abs(m.changePct) > 0.5)
    return { regime: 'trending', strategy: 'Momentum' };
  return { regime: 'ranging', strategy: 'Mean Reversion' };
}

// ─── Memory context ───────────────────────────────────────
function buildMemoryContext() {
  if (!state.memories.length) return 'No trade history yet.';
  const recent = state.memories.slice(0, 8).map(m =>
    `[${m.won ? 'WIN' : 'LOSS'}] ${m.ticker} ${m.strategy} ${m.regime} RSI:${m.rsi} ${m.price > m.vwap ? 'aboveVWAP' : 'belowVWAP'} Conf:${m.conf}/10 PnL:${m.pnl >= 0 ? '+' : ''}$${Math.abs(m.pnl).toFixed(0)} Lesson:${m.lesson || 'none'}`
  ).join('\n');
  const stratPerf = Object.entries(state.stratStats)
    .filter(([, d]) => d.w + d.l > 0)
    .map(([s, d]) => `${s}:${Math.round(d.w / (d.w + d.l) * 100)}%WR(${d.w + d.l}t)`)
    .join(' | ');
  const topLessons = state.lessons.slice(0, 4).map(l => `• ${l.lesson}`).join('\n');
  return `TRADE MEMORY (${state.memories.length} trades):\n${recent}\nStrategy performance: ${stratPerf || 'none yet'}\n${state.lessons.length ? 'Lessons:\n' + topLessons : ''}`;
}

// ─── Claude API ───────────────────────────────────────────
async function callClaude(prompt, maxTokens = 800) {
  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CONFIG.anthropicKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: maxTokens,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    const data = await resp.json();
    if (!data?.content?.length) return null;
    return data.content.map(b => b.text || '').join('');
  } catch (e) {
    console.error('Claude API error:', e.message);
    return null;
  }
}

function buildTradePrompt(m, strategy, regime, equity) {
  const maxRiskAmt = equity * (CONFIG.maxRiskPct / 100);
  const shares = Math.max(1, Math.floor(maxRiskAmt / (m.atr || m.price * 0.015)));
  return `You are a professional day trader AI with expert knowledge and trade memory. Analyze and decide.

MARKET: ${m.ticker} $${m.price} (${m.changePct > 0 ? '+' : ''}${m.changePct}%) RSI:${m.rsi} VWAP:$${m.vwap}(${m.price > m.vwap ? 'ABOVE' : 'BELOW'}) VOL:${m.volRatio}x ATR:$${m.atr} MACD:${m.macd > 0 ? 'BULL' : 'BEAR'} TREND:${m.trend} REGIME:${regime.toUpperCase()} STRATEGY:${strategy}
ACCOUNT: equity $${equity.toFixed(0)} | max risk $${maxRiskAmt.toFixed(0)} | suggested shares: ${shares}

${buildMemoryContext()}

${EXPERT_KNOWLEDGE}

STRATEGY: ${strategy === 'Momentum' ? 'Buy>VWAP+RSI50-70+MACDbull+vol>1.2x. Short<VWAP+RSI30-50+MACDbear.' : strategy === 'Mean Reversion' ? 'Buy RSI<35+price<VWAP. Short RSI>68+price>VWAP. Target VWAP.' : 'Buy confirmed break vol>1.4x. Stop 1.5xATR. No chasing.'}
RISK: Never risk>$${maxRiskAmt.toFixed(0)}. Stop required. 1:2 RR minimum. If weak setup → HOLD.

Reply EXACTLY:
DECISION: BUY or SELL or HOLD
SHARES: ${shares}
ENTRY: $${m.price}
STOP: $[price]
TARGET: $[price]
CONFIDENCE: [1-10]
REASONING: [2-3 sentences]`;
}

function buildLearnPrompt(trade, won) {
  return `Trading AI reviewing trade outcome to improve.
TRADE: ${trade.action} ${trade.ticker} via ${trade.strategy} in ${trade.regime} regime
RSI:${trade.rsi} VWAP:${trade.price > trade.vwap ? 'above' : 'below'} VOL:${trade.volRatio}x Conf:${trade.conf}/10
OUTCOME: ${won ? 'WIN' : 'LOSS'} PnL:${trade.pnl >= 0 ? '+' : ''}$${Math.abs(trade.pnl).toFixed(2)}
Reply EXACTLY:
LESSON: [one actionable sentence]
PATTERN: [pattern in 8 words]
CONF_OK: yes or no
STRAT_FIT: good or poor`;
}

// ─── IQ calculation ───────────────────────────────────────
function calcIQ() {
  const n = state.trades.length;
  if (n < 3) return 50;
  const wr = state.wins / n;
  const memBonus = Math.min(20, state.memories.length * 2);
  let stratBonus = 0;
  Object.values(state.stratStats).forEach(s => {
    const t = s.w + s.l;
    if (t >= 3 && s.w / t > 0.55) stratBonus += 3;
  });
  return Math.max(10, Math.min(100,
    Math.round(50 + (wr - 0.5) * 40 + (state.totalPnl / n > 0 ? 10 : 0) + memBonus + Math.min(10, stratBonus))
  ));
}

// ─── Core trade loop ──────────────────────────────────────
async function analyzeTicker(ticker) {
  console.log(`\n🔍 Analyzing ${ticker}...`);

  // Get real market data
  const m = await getMarketData(ticker);
  if (!m) {
    console.log(`  ⚠ No market data for ${ticker}`);
    return null;
  }

  // Get account info
  let equity = 100000;
  try {
    const account = await getAccount();
    equity = parseFloat(account.equity);
  } catch (e) {
    console.error('  Account fetch failed:', e.message);
  }

  // Detect regime
  const r = detectRegime(m);
  console.log(`  Regime: ${r.regime} | Strategy: ${r.strategy} | Price: $${m.price} | RSI: ${m.rsi}`);

  // Call Claude
  const text = await callClaude(buildTradePrompt(m, r.strategy, r.regime, equity), 700);
  if (!text) {
    console.log(`  ⚠ No Claude response for ${ticker}`);
    return null;
  }

  // Parse decision
  const get = k => { const x = text.match(new RegExp(k + ':\\s*(.+)')); return x ? x[1].trim() : null; };
  const rawDecision = get('DECISION') || 'HOLD';
  const action = rawDecision.toUpperCase().includes('BUY') ? 'BUY'
    : rawDecision.toUpperCase().includes('SELL') ? 'SELL' : 'HOLD';
  const shares = parseInt(get('SHARES')) || 10;
  const entry = get('ENTRY') || '$' + m.price;
  const stop = get('STOP') || '—';
  const target = get('TARGET') || '—';
  const confidence = parseInt(get('CONFIDENCE')) || 5;
  const rm = text.match(/REASONING:\s*([\s\S]+?)(?:\n[A-Z_]+:|$)/);
  const reasoning = rm ? rm[1].trim() : '';

  console.log(`  Decision: ${action} | Confidence: ${confidence}/10 | Shares: ${shares}`);
  console.log(`  Reasoning: ${reasoning.slice(0, 100)}...`);

  return { action, shares, entry, stop, target, confidence, reasoning, market: m, regime: r };
}

async function executeTrade(decision) {
  const { action, shares, entry, stop, target, confidence, reasoning, market: m, regime: r } = decision;

  // Risk gates
  if (confidence < CONFIG.minConfidence) {
    console.log(`  ⚠ Confidence ${confidence} below minimum ${CONFIG.minConfidence} — skipping`);
    return;
  }
  if (state.dailyLoss >= CONFIG.dailyLossLimit) {
    console.log(`  🛑 Daily loss limit $${CONFIG.dailyLossLimit} reached — no more trades today`);
    await sendEmail(
      '🛑 APEX Trader — Daily Loss Limit Hit',
      `The agent has stopped trading for today.\n\nDaily loss limit: $${CONFIG.dailyLossLimit}\nLoss so far: $${state.dailyLoss.toFixed(2)}\n\nTrading will resume tomorrow morning.`
    );
    return;
  }

  // Check open positions
  let positions = [];
  try {
    positions = await getPositions();
  } catch (e) {}
  if (positions.length >= CONFIG.maxPositions) {
    console.log(`  ⚠ At max positions (${CONFIG.maxPositions}) — skipping`);
    return;
  }

  // ── Smart limit order with slippage protection ────────────
  const side = action === 'BUY' ? 'buy' : 'sell';

  // Re-fetch price to check for drift since Claude analyzed
  // If price moved >0.5% while Claude was thinking, skip to avoid chasing
  const freshData = await getMarketData(m.ticker);
  if (freshData) {
    const drift = Math.abs(freshData.price - m.price) / m.price;
    if (drift > 0.005) {
      console.log(`  ⚠ Price drifted ${(drift*100).toFixed(2)}% — skipping ${m.ticker} to avoid chasing`);
      await sendEmail(
        `⚠ APEX Skipped ${m.ticker} — Price Drift`,
        `${action} ${m.ticker} skipped — price moved ${(drift*100).toFixed(2)}% during analysis.\nAnalysis: $${m.price} | Now: $${freshData.price}\nAgent re-evaluates next cycle.`
      );
      return;
    }
    // Use fresh price for limit
    m.price = freshData.price;
  }

  // Limit price: 0.05% above market for buys, 0.05% below for sells
  // Fills fast on liquid stocks, but won't chase a moving price
  const buf = 0.0005;
  const limitPrice = action === 'BUY'
    ? +(m.price * (1 + buf)).toFixed(2)
    : +(m.price * (1 - buf)).toFixed(2);

  // Parse stop and target from Claude's response
  const stopPrice = parseFloat((stop||'0').replace(/[^0-9.]/g,'')) || null;
  const targetPrice = parseFloat((target||'0').replace(/[^0-9.]/g,'')) || null;
  const hasBracket = stopPrice > 0 && targetPrice > 0 &&
    (action === 'BUY' ? targetPrice > m.price && stopPrice < m.price
                      : targetPrice < m.price && stopPrice > m.price);

  // Build order — bracket if valid stop+target, otherwise plain limit
  const orderBody = {
    symbol: m.ticker,
    qty: shares,
    side,
    type: 'limit',
    limit_price: limitPrice,
    time_in_force: 'day', // expires end of day — no overnight risk
  };

  if (hasBracket) {
    orderBody.order_class = 'bracket';
    orderBody.take_profit = { limit_price: +targetPrice.toFixed(2) };
    orderBody.stop_loss = { stop_price: +stopPrice.toFixed(2) };
    console.log(`  Bracket order: ${action} @ $${limitPrice} | stop $${stopPrice} | target $${targetPrice}`);
  } else {
    console.log(`  Limit order: ${action} ${shares} ${m.ticker} @ $${limitPrice}`);
  }

  try {
    const order = await alpacaPost('/v2/orders', orderBody);

    const tradeRecord = {
      id: order.id,
      time: new Date().toISOString(),
      ticker: m.ticker,
      action,
      shares,
      entry,
      stop,
      target,
      conf: confidence,
      strategy: r.strategy,
      regime: r.regime,
      rsi: m.rsi,
      vwap: m.vwap,
      price: m.price,
      volRatio: m.volRatio,
      trend: m.trend,
      reasoning,
      mode: CONFIG.alpacaMode,
    };
    state.trades.unshift(tradeRecord);

    console.log(`  ✅ Order placed: ${action} ${shares} shares ${m.ticker} | ID: ${order.id?.slice(0, 8)}`);

    // Send email alert
    await sendEmail(
      `${CONFIG.alpacaMode === 'live' ? '💰 LIVE' : '📄 PAPER'} ORDER — ${action} ${m.ticker}`,
      `${action} ${shares} shares of ${m.ticker}

ORDER TYPE: ${hasBracket ? 'BRACKET (auto stop + target)' : 'LIMIT'}
Limit price: $${limitPrice}
Stop loss: ${stop} ${hasBracket ? '(AUTO — set on exchange)' : '(MANUAL — monitor)'}
Target: ${target} ${hasBracket ? '(AUTO — set on exchange)' : '(MANUAL — monitor)'}
Strategy: ${r.strategy} | Regime: ${r.regime}
Confidence: ${confidence}/10

Reasoning: ${reasoning}

Order ID: ${order.id?.slice(0, 12)}
Mode: ${CONFIG.alpacaMode.toUpperCase()}
Session P&L: ${state.totalPnl >= 0 ? '+' : ''}$${state.totalPnl.toFixed(2)}
Agent IQ: ${state.agentIQ} | Memories: ${state.memories.length}

You will receive another email when this position closes with the real P&L.`
    );

    // Watch real outcome — tracks position until it closes, then learns from actual P&L
    // Runs async so it doesn't block the next scan cycle
    watchTradeOutcome(tradeRecord, order.id);

    saveState();

  } catch (e) {
    console.error(`  ❌ Order failed for ${m.ticker}:`, e.message);
    await sendEmail(
      `⚠ APEX Trader — Order Failed: ${m.ticker}`,
      `Failed to place ${action} order for ${m.ticker}\nError: ${e.message}\nThe agent will continue scanning other tickers.`
    );
  }
}

// ─── Real outcome tracking ────────────────────────────────
// Watches open orders and positions using real Alpaca data.
// When a position closes (stop or target hit), records the actual
// P&L and feeds it to Claude for genuine learning.

async function watchTradeOutcome(trade, orderId) {
  const MAX_WAIT_MS = 6 * 60 * 60 * 1000; // 6 hours max watch
  const CHECK_INTERVAL_MS = 60 * 1000;     // Check every 60 seconds
  const startTime = Date.now();

  console.log(`  👁 Watching ${trade.ticker} order ${orderId?.slice(0,8)} for real outcome...`);

  // Wait for order to fill first
  await new Promise(r => setTimeout(r, 5000));

  let fillPrice = trade.price;
  let filled = false;

  // Check if order filled
  try {
    const orderStatus = await alpacaGet('/v2/orders/' + orderId);
    if (orderStatus.status === 'filled') {
      fillPrice = parseFloat(orderStatus.filled_avg_price) || trade.price;
      filled = true;
      const slippage = Math.abs(fillPrice - trade.price);
      console.log(`  ✓ Filled @ $${fillPrice} (slippage: $${slippage.toFixed(3)})`);
    } else if (orderStatus.status === 'canceled' || orderStatus.status === 'expired') {
      console.log(`  ✗ Order ${orderId?.slice(0,8)} ${orderStatus.status} — no position opened`);
      return; // No trade happened, nothing to learn
    }
  } catch(e) {
    console.error('  Order status check failed:', e.message);
  }

  if (!filled) {
    console.log(`  Order not yet filled — will check position directly`);
  }

  // Now watch the position for close
  let checkCount = 0;
  const interval = setInterval(async () => {
    checkCount++;
    try {
      // Check if position still open
      const positions = await getPositions();
      const pos = positions.find(p => p.symbol === trade.ticker);

      if (!pos) {
        // Position closed — get the real P&L from recent activities
        clearInterval(interval);
        const realPnl = await getRealTradePnl(trade, orderId, fillPrice);
        await learnFromRealOutcome(trade, realPnl, fillPrice);
        return;
      }

      // Position still open — log current P&L
      const unrealizedPnl = parseFloat(pos.unrealized_pl || 0);
      const unrealizedPct = parseFloat(pos.unrealized_plpc || 0) * 100;
      if (checkCount % 5 === 0) { // Log every 5 minutes
        console.log(`  📊 ${trade.ticker} open: P&L ${unrealizedPnl >= 0 ? '+' : ''}$${unrealizedPnl.toFixed(2)} (${unrealizedPct.toFixed(2)}%)`);
      }

      // Send alert if position up significantly (>3%)
      if (unrealizedPct > 3 && checkCount === 1) {
        await sendEmail(
          `📈 ${trade.ticker} UP ${unrealizedPct.toFixed(1)}% — Consider Taking Profit`,
          `Your ${trade.action} position in ${trade.ticker} is up ${unrealizedPct.toFixed(1)}%\nUnrealized P&L: +$${unrealizedPnl.toFixed(2)}\nTarget was: ${trade.target}\nCurrent price: $${pos.current_price}`
        );
      }

      // Alert if near stop loss (within 0.3%)
      const stopPrice = parseFloat((trade.stop||'0').replace(/[^0-9.]/g,''));
      if (stopPrice > 0) {
        const distToStop = Math.abs(parseFloat(pos.current_price) - stopPrice) / parseFloat(pos.current_price);
        if (distToStop < 0.003 && checkCount % 3 === 0) {
          await sendEmail(
            `⚠ ${trade.ticker} NEAR STOP LOSS`,
            `${trade.ticker} is approaching your stop loss!\nCurrent: $${pos.current_price}\nStop: $${stopPrice}\nDistance: ${(distToStop*100).toFixed(2)}%`
          );
        }
      }

    } catch(e) {
      // Position likely closed if we get an error fetching it
      clearInterval(interval);
      const realPnl = await getRealTradePnl(trade, orderId, fillPrice);
      await learnFromRealOutcome(trade, realPnl, fillPrice);
    }

    // Timeout after max wait
    if (Date.now() - startTime > MAX_WAIT_MS) {
      clearInterval(interval);
      console.log(`  ⏰ Max watch time reached for ${trade.ticker}`);
      const realPnl = await getRealTradePnl(trade, orderId, fillPrice);
      await learnFromRealOutcome(trade, realPnl, fillPrice);
    }
  }, CHECK_INTERVAL_MS);
}

async function getRealTradePnl(trade, orderId, fillPrice) {
  // Try to get actual P&L from Alpaca account activities
  try {
    const resp = await fetch(
      `${ALPACA_BASE}/v2/account/activities?activity_types=FILL&limit=20`,
      { headers: { 'APCA-API-KEY-ID': CONFIG.alpacaKey, 'APCA-API-SECRET-KEY': CONFIG.alpacaSecret } }
    );
    const activities = await resp.json();

    // Find the closing fill for this ticker
    const closingFills = activities.filter(a =>
      a.symbol === trade.ticker &&
      new Date(a.transaction_time) > new Date(trade.time)
    );

    if (closingFills.length > 0) {
      const closeFill = closingFills[0];
      const closePrice = parseFloat(closeFill.price);
      const qty = parseInt(closeFill.qty);
      const pnl = trade.action === 'BUY'
        ? (closePrice - fillPrice) * qty
        : (fillPrice - closePrice) * qty;
      console.log(`  💰 Real P&L for ${trade.ticker}: ${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`);
      return +pnl.toFixed(2);
    }
  } catch(e) {
    console.error('  P&L fetch error:', e.message);
  }

  // Fallback: estimate from target/stop
  const stopPrice = parseFloat((trade.stop||'0').replace(/[^0-9.]/g,'')) || 0;
  const targetPrice = parseFloat((trade.target||'0').replace(/[^0-9.]/g,'')) || 0;
  const shares = trade.shares || 10;
  if (stopPrice > 0) {
    const risk = Math.abs(fillPrice - stopPrice) * shares;
    return -risk; // Assume stop hit if we can't determine
  }
  return 0;
}

async function learnFromRealOutcome(trade, realPnl, fillPrice) {
  const won = realPnl > 0;
  const slippage = Math.abs(fillPrice - trade.price);

  console.log(`  🧠 Learning from REAL outcome: ${trade.ticker} ${won ? 'WIN' : 'LOSS'} $${realPnl.toFixed(2)} | Slippage: $${slippage.toFixed(3)}`);

  // Update global P&L and stats
  state.totalPnl = +(state.totalPnl + realPnl).toFixed(2);
  if (won) state.wins++; else state.losses++;
  if (realPnl < 0) state.dailyLoss = +(state.dailyLoss + Math.abs(realPnl)).toFixed(2);

  const sk = trade.strategy;
  if (state.stratStats[sk]) {
    won ? state.stratStats[sk].w++ : state.stratStats[sk].l++;
    state.stratStats[sk].pnl = +(state.stratStats[sk].pnl + realPnl).toFixed(2);
  }

  // Send real outcome email
  await sendEmail(
    `${won ? '✅ WIN' : '❌ LOSS'} — ${trade.ticker} closed | ${won ? '+' : ''}$${realPnl.toFixed(2)}`,
    `Position closed: ${trade.action} ${trade.shares} ${trade.ticker}
Real P&L: ${realPnl >= 0 ? '+' : ''}$${realPnl.toFixed(2)}
Fill price: $${fillPrice} | Close price: $${(fillPrice + realPnl/trade.shares).toFixed(2)}
Slippage from analysis: $${slippage.toFixed(3)} per share
Strategy: ${trade.strategy} | Regime: ${trade.regime}
Confidence was: ${trade.conf}/10

Running totals:
Session P&L: ${state.totalPnl >= 0 ? '+' : ''}$${state.totalPnl.toFixed(2)}
Win rate: ${state.wins + state.losses > 0 ? Math.round(state.wins/(state.wins+state.losses)*100) : 0}% (${state.wins}W/${state.losses}L)
Agent IQ: ${state.agentIQ}`
  );

  // Build real learning prompt with actual outcome
  const learnPrompt = `Trading AI reviewing REAL trade outcome (not simulated).
TRADE: ${trade.action} ${trade.shares} ${trade.ticker} via ${trade.strategy} in ${trade.regime} regime
Entry: $${fillPrice} | Slippage: $${slippage.toFixed(3)}/share
RSI at entry: ${trade.rsi} | VWAP: ${fillPrice > trade.vwap ? 'above' : 'below'} | Vol: ${trade.volRatio}x
Confidence: ${trade.conf}/10 | Reasoning was: ${trade.reasoning?.slice(0, 150)}
REAL OUTCOME: ${won ? 'WIN' : 'LOSS'} | P&L: ${realPnl >= 0 ? '+' : ''}$${realPnl.toFixed(2)}
${slippage > 0.05 ? 'NOTE: Significant slippage occurred — price moved before fill.' : ''}

Reply EXACTLY:
LESSON: [one specific actionable sentence based on this REAL outcome]
PATTERN: [the setup pattern in 8 words]
CONF_OK: yes or no
STRAT_FIT: good or poor
SLIPPAGE_NOTE: [was slippage a factor? yes or no and why]`;

  const text = await callClaude(learnPrompt, 300);
  const get = k => { const x = (text||'').match(new RegExp(k + ':\s*(.+)')); return x ? x[1].trim() : null; };
  const lesson = get('LESSON') || (won ? 'This setup works — reinforce similar entries.' : 'This setup failed — be more selective.');
  const pattern = get('PATTERN') || '—';
  const confOk = get('CONF_OK') || 'yes';
  const stratFit = get('STRAT_FIT') || 'good';
  const slippageNote = get('SLIPPAGE_NOTE') || 'no';

  const memory = {
    ticker: trade.ticker, strategy: trade.strategy, regime: trade.regime,
    rsi: trade.rsi, vwap: trade.vwap, price: fillPrice,
    volRatio: trade.volRatio, trend: trade.trend, conf: trade.conf,
    action: trade.action, pnl: realPnl, won, lesson, pattern, confOk, stratFit,
    slippage, slippageNote, real: true,
    time: new Date().toLocaleTimeString(),
  };
  state.memories.unshift(memory);
  if (state.memories.length > 200) state.memories = state.memories.slice(0, 200);

  if (!won || confOk === 'no' || stratFit === 'poor') {
    state.lessons.unshift({ lesson, pattern, won, strategy: trade.strategy, regime: trade.regime, time: memory.time });
    if (state.lessons.length > 50) state.lessons = state.lessons.slice(0, 50);
  }

  // Confidence calibration
  const c = parseInt(trade.conf) || 5;
  const bi = c <= 4 ? 0 : c <= 6 ? 1 : c <= 8 ? 2 : 3;
  state.confBuckets[bi].s++;
  if (won) state.confBuckets[bi].w++;

  state.agentIQ = calcIQ();
  console.log(`  ✓ Real learning complete | IQ now: ${state.agentIQ} | Lesson: "${lesson.slice(0,60)}..."`);
  saveState();
}

// Keep old learnFromSetup as fallback for paper mode
async function learnFromSetup(trade) {
  // Used in pure paper mode — estimates outcome while position is open
  // Will be replaced by real outcome when position closes via watchTradeOutcome
  await new Promise(r => setTimeout(r, 30000)); // Wait 30s before estimating

  // Try to get current position P&L
  try {
    const positions = await getPositions();
    const pos = positions.find(p => p.symbol === trade.ticker);
    if (pos) {
      const pnl = parseFloat(pos.unrealized_pl || 0);
      const won = pnl > 0;
      await learnFromRealOutcome(trade, pnl, parseFloat(pos.avg_entry_price || trade.price));
      return;
    }
  } catch(e) {}

  // Fallback if position already closed or not found
  const won = Math.random() > 0.45;
  const pnl = won ? +(trade.shares * trade.price * 0.015).toFixed(2) : -(trade.shares * trade.price * 0.01).toFixed(2);
  await learnFromRealOutcome(trade, pnl, trade.price);
}

// ─── Main scan loop ───────────────────────────────────────
async function runScanCycle() {
  if (!state.isRunning) return;

  checkDailyReset();

  // Check daily loss limit
  if (state.dailyLoss >= CONFIG.dailyLossLimit) {
    console.log('🛑 Daily loss limit reached — pausing until tomorrow');
    return;
  }

  console.log(`\n━━━ Scan cycle ${new Date().toLocaleTimeString()} ━━━`);

  // Shuffle watchlist for variety
  const shuffled = [...WATCHLIST].sort(() => Math.random() - 0.5);

  for (const ticker of shuffled) {
    if (!state.isRunning) break;

    const decision = await analyzeTicker(ticker);
    if (decision && decision.action !== 'HOLD') {
      await executeTrade(decision);
      // Small delay between trades
      await new Promise(r => setTimeout(r, 2000));
    }
  }

  state.lastScanTime = new Date().toISOString();
  console.log(`━━━ Cycle complete. IQ: ${state.agentIQ} | Trades: ${state.trades.length} | Memories: ${state.memories.length} ━━━\n`);
}

// ─── Morning scan (9:30 AM ET) ────────────────────────────
// Cron: '30 9 * * 1-5' = 9:30 on weekdays (adjust for your timezone offset)
cron.schedule('30 13 * * 1-5', async () => {
  // 13:30 UTC = 9:30 AM ET (UTC-4 during EDT)
  console.log('🌅 Market open scan triggered');
  await sendEmail(
    '🌅 APEX Trader — Market Open Scanner Running',
    `Good morning! Market just opened.\n\nThe agent is scanning ${WATCHLIST.length} stocks for today's best opportunities.\nIQ: ${state.agentIQ} | Memories: ${state.memories.length} | Lessons: ${state.lessons.length}`
  );
  await runScanCycle();
}, { timezone: 'America/New_York' });

// ─── Regular scan interval ────────────────────────────────
let scanIntervalTimer = null;

function startScanInterval() {
  if (scanIntervalTimer) clearInterval(scanIntervalTimer);
  scanIntervalTimer = setInterval(runScanCycle, CONFIG.scanIntervalMins * 60 * 1000);
  console.log(`⏱ Scan interval set: every ${CONFIG.scanIntervalMins} minutes`);
}

// ─── Daily P&L summary email (4:30 PM ET) ────────────────
cron.schedule('30 20 * * 1-5', async () => {
  // 20:30 UTC = 4:30 PM ET
  const n = state.trades.length;
  const wr = n ? Math.round(state.wins / n * 100) : 0;
  await sendEmail(
    `📊 APEX Trader — Daily Summary`,
    `Market close summary for ${new Date().toLocaleDateString()}

PERFORMANCE
Total P&L: ${state.totalPnl >= 0 ? '+' : ''}$${state.totalPnl.toFixed(2)}
Daily loss: $${state.dailyLoss.toFixed(2)} (limit: $${CONFIG.dailyLossLimit})
Win rate: ${wr}% (${state.wins}W / ${state.losses}L)
Total trades: ${n}

AGENT STATUS
IQ score: ${state.agentIQ}/100
Memories stored: ${state.memories.length}
Lessons learned: ${state.lessons.length}
Mode: ${CONFIG.alpacaMode.toUpperCase()}

${state.lessons.length > 0 ? 'LATEST LESSON:\n' + state.lessons[0].lesson : ''}

The agent will resume scanning at market open tomorrow.`
  );
}, { timezone: 'America/New_York' });

// ─── REST API (for dashboard to connect to) ───────────────
app.get('/status', (req, res) => {
  res.json({
    isRunning: state.isRunning,
    agentIQ: state.agentIQ,
    memories: state.memories.length,
    lessons: state.lessons.length,
    trades: state.trades.length,
    totalPnl: state.totalPnl,
    wins: state.wins,
    losses: state.losses,
    dailyLoss: state.dailyLoss,
    mode: CONFIG.alpacaMode,
    lastScanTime: state.lastScanTime,
  });
});

app.get('/trades', (req, res) => {
  res.json(state.trades.slice(0, 50));
});

app.get('/memories', (req, res) => {
  res.json(state.memories.slice(0, 50));
});

app.get('/lessons', (req, res) => {
  res.json(state.lessons.slice(0, 20));
});

app.post('/start', (req, res) => {
  state.isRunning = true;
  saveState();
  startScanInterval();
  runScanCycle(); // Run immediately
  console.log('▶ Agent started via API');
  sendEmail('▶ APEX Trader Started', `The trading agent has been started.\nMode: ${CONFIG.alpacaMode.toUpperCase()}\nScan interval: every ${CONFIG.scanIntervalMins} minutes`);
  res.json({ success: true, message: 'Agent started' });
});

app.post('/stop', (req, res) => {
  state.isRunning = false;
  if (scanIntervalTimer) { clearInterval(scanIntervalTimer); scanIntervalTimer = null; }
  saveState();
  console.log('⏹ Agent stopped via API');
  sendEmail('⏹ APEX Trader Stopped', `The trading agent has been stopped.\nFinal IQ: ${state.agentIQ}\nTotal trades: ${state.trades.length}\nP&L: ${state.totalPnl >= 0 ? '+' : ''}$${state.totalPnl.toFixed(2)}`);
  res.json({ success: true, message: 'Agent stopped' });
});

app.post('/scan-now', async (req, res) => {
  res.json({ success: true, message: 'Scan started' });
  await runScanCycle();
});

app.get('/positions', async (req, res) => {
  try {
    const positions = await getPositions();
    res.json(positions);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/positions', async (req, res) => {
  try {
    await fetch(ALPACA_BASE + '/v2/positions', {
      method: 'DELETE',
      headers: {
        'APCA-API-KEY-ID': CONFIG.alpacaKey,
        'APCA-API-SECRET-KEY': CONFIG.alpacaSecret,
      },
    });
    res.json({ success: true });
    sendEmail('⬛ All Positions Closed', 'All open positions have been closed via the dashboard.');
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Health check for Railway
app.get('/', (req, res) => {
  res.send(`APEX Trader Server running | Mode: ${CONFIG.alpacaMode} | IQ: ${state.agentIQ} | Running: ${state.isRunning}`);
});

// ─── Start server ─────────────────────────────────────────
app.listen(CONFIG.port, () => {
  console.log(`\n🚀 APEX Trader Server started on port ${CONFIG.port}`);
  console.log(`   Mode: ${CONFIG.alpacaMode.toUpperCase()}`);
  console.log(`   Scan interval: every ${CONFIG.scanIntervalMins} minutes`);
  console.log(`   Min confidence: ${CONFIG.minConfidence}/10`);
  console.log(`   Daily loss limit: $${CONFIG.dailyLossLimit}`);
  console.log(`   Max positions: ${CONFIG.maxPositions}`);

  loadState();
  console.log(`\n   POST /start  → start the agent`);
  console.log(`   POST /stop   → stop the agent`);
  console.log(`   GET  /status → check status\n`);

  // Auto-start if was running before restart
  if (state.isRunning) {
    console.log('↺ Auto-resuming from previous state...');
    startScanInterval();
  }
});
