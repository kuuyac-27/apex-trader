/**
 * APEX TRADER SERVER
 * 24/7 autonomous trading agent
 * Runs Claude AI analysis, places Alpaca orders, sends email alerts
 */

require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const nodemailer = require('nodemailer');
const cron = require('node-cron');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// ─── Config ───────────────────────────────────────────────
const CONFIG = {
  anthropicKey: process.env.ANTHROPIC_API_KEY,
  alpacaKey: process.env.ALPACA_API_KEY,
  alpacaSecret: process.env.ALPACA_API_SECRET,
  alpacaMode: process.env.ALPACA_MODE || 'paper',
  emailFrom: process.env.EMAIL_FROM,
  emailPassword: process.env.EMAIL_PASSWORD,
  emailTo: process.env.EMAIL_TO,
  maxRiskPct: parseFloat(process.env.MAX_RISK_PER_TRADE) || 1.5,
  dailyLossLimit: parseFloat(process.env.DAILY_LOSS_LIMIT) || 500,
  maxPositions: parseInt(process.env.MAX_OPEN_POSITIONS) || 3,
  minConfidence: parseInt(process.env.MIN_CONFIDENCE) || 6,
  scanIntervalMins: parseInt(process.env.SCAN_INTERVAL_MINUTES) || 5,
  port: parseInt(process.env.PORT) || 3000,
};

const ALPACA_BASE = CONFIG.alpacaMode === 'live'
  ? 'https://api.alpaca.markets'
  : 'https://paper-api.alpaca.markets';
const ALPACA_DATA = 'https://data.alpaca.markets';

// ─── State (persisted to disk) ────────────────────────────
const STATE_FILE = path.join(__dirname, 'state.json');

let state = {
  memories: [],
  lessons: [],
  trades: [],
  stratStats: {
    Momentum: { w: 0, l: 0, pnl: 0 },
    'Mean Reversion': { w: 0, l: 0, pnl: 0 },
    Breakout: { w: 0, l: 0, pnl: 0 },
  },
  confBuckets: [
    { label: '1-4', s: 0, w: 0 },
    { label: '5-6', s: 0, w: 0 },
    { label: '7-8', s: 0, w: 0 },
    { label: '9-10', s: 0, w: 0 },
  ],
  dailyLoss: 0,
  totalPnl: 0,
  wins: 0,
  losses: 0,
  isRunning: false,
  lastScanTime: null,
  agentIQ: 50,
  lastResetDate: new Date().toDateString(),
};

// Expert knowledge - injected into every prompt
const EXPERT_KNOWLEDGE = `
TECHNICAL PRINCIPLES:
- VWAP anchor: Price above VWAP = bullish. Below = bearish. Never long below VWAP in downtrend without strong reversal.
- RSI divergence: Price new highs + RSI fails = reversal. New lows + RSI rises = bounce. Strongest signal.
- Volume confirms moves: Breakout without 1.5x+ avg volume is suspect. High vol = conviction. Low vol = fade.
- Support becomes resistance: Old support flips to resistance when broken. Trade these flip zones.
- First 15 min rule: Wait for initial range to form after open. Most volatile, emotion-driven period.
- ATR sizing: Stop = 1-1.5x ATR from entry. Gives trade room to breathe.
- Risk/reward minimum: Never take <1:2 RR. At 40% win rate you're profitable at 1:2.
- Power hour: Last hour (3-4pm ET) = high volume, accelerated moves. Bigger risk and reward.

FUNDAMENTAL PRINCIPLES:
- Earnings drift (PEAD): Stocks beating estimates 10%+ drift higher for days. Trade the drift.
- News = surprise: Stocks move on surprise not known news. If priced in, reaction may reverse.
- Short squeeze fuel: High short interest (>20% float) + catalyst = explosive upside. Know the float.
- Institutional footprints: High vol with no news = smart money accumulating or distributing.
- Relative strength: Stocks holding green in down market = RS. First to recover when market turns.
- 52-week highs: No overhead resistance = price discovery. Clean momentum trades with volume.
- Float matters: Small float (<20M shares) moves faster and further. Match strategy to float.
- Risk-off check: VIX>25 = reduce all sizes 50%. The tide affects all boats.
`;

// Watchlist - scanned repeatedly
const WATCHLIST = [
  'AAPL', 'MSFT', 'NVDA', 'TSLA', 'META',
  'SPY', 'QQQ', 'IWM', 'AMD', 'AMZN',
  'PLTR', 'CRWD', 'NET', 'COIN', 'JPM',
];

// ─── Persist state ────────────────────────────────────────
function saveState() {
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  } catch (e) {
    console.error('Failed to save state:', e.message);
  }
}

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const saved = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      state = { ...state, ...saved };
      console.log(`✓ Loaded state: ${state.memories.length} memories, ${state.trades.length} trades, IQ ${state.agentIQ}`);
    }
  } catch (e) {
    console.error('Failed to load state:', e.message);
  }
}

// ─── Daily reset (P&L tracking only, keep memory) ─────────
function checkDailyReset() {
  const today = new Date().toDateString();
  if (state.lastResetDate !== today) {
    state.dailyLoss = 0;
    state.lastResetDate = today;
    saveState();
    console.log('📅 Daily P&L reset for', today);
    sendEmail(
      '📅 APEX Trader — New Trading Day',
      `Good morning! A new trading day has started.\n\nAgent IQ: ${state.agentIQ}\nMemories: ${state.memories.length}\nLessons: ${state.lessons.length}\n\nThe agent is ready to scan and trade.`
    );
  }
}

// ─── Email alerts ─────────────────────────────────────────
const emailTransporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: CONFIG.emailFrom,
    pass: CONFIG.emailPassword,
  },
});

async function sendEmail(subject, body) {
  if (!CONFIG.emailFrom || !CONFIG.emailPassword || !CONFIG.emailTo) {
    console.log('Email not configured — skipping:', subject);
    return;
  }
  try {
    await emailTransporter.sendMail({
      from: `APEX Trader <${CONFIG.emailFrom}>`,
      to: CONFIG.emailTo,
      subject,
      html: `
        <div style="font-family:monospace;background:#07080b;color:#dde2f0;padding:24px;border-radius:8px;max-width:500px">
          <div style="color:#00e5b0;font-size:16px;font-weight:bold;margin-bottom:16px">◈ APEX TRADER</div>
          <pre style="white-space:pre-wrap;font-size:14px;line-height:1.7;color:#dde2f0">${body}</pre>
          <div style="margin-top:16px;font-size:11px;color:#424d6a">
            Mode: ${CONFIG.alpacaMode.toUpperCase()} · IQ: ${state.agentIQ} · Memories: ${state.memories.length}
          </div>
        </div>
      `,
    });
    console.log('📧 Email sent:', subject);
  } catch (e) {
    console.error('Email failed:', e.message);
  }
}

// ─── Alpaca API ───────────────────────────────────────────
async function alpacaGet(path) {
  const resp = await fetch(ALPACA_BASE + path, {
    headers: {
      'APCA-API-KEY-ID': CONFIG.alpacaKey,
      'APCA-API-SECRET-KEY': CONFIG.alpacaSecret,
    },
  });
  if (!resp.ok) throw new Error(`Alpaca ${path}: HTTP ${resp.status}`);
  return resp.json();
}

async function alpacaPost(path, body) {
  const resp = await fetch(ALPACA_BASE + path, {
    method: 'POST',
    headers: {
      'APCA-API-KEY-ID': CONFIG.alpacaKey,
      'APCA-API-SECRET-KEY': CONFIG.alpacaSecret,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  const text = await resp.text();
  if (!resp.ok) throw new Error(`Alpaca POST ${path}: ${text}`);
  return JSON.parse(text);
}

async function getAccount() {
  return alpacaGet('/v2/account');
}

async function getPositions() {
  return alpacaGet('/v2/positions');
}

async function getMarketData(ticker) {
  try {
    const end = new Date().toISOString();
    const start = new Date(Date.now() - 3600000 * 2).toISOString();
    const resp = await fetch(
      `${ALPACA_DATA}/v2/stocks/${ticker}/bars?timeframe=5Min&start=${start}&end=${end}&limit=30`,
      {
        headers: {
          'APCA-API-KEY-ID': CONFIG.alpacaKey,
          'APCA-API-SECRET-KEY': CONFIG.alpacaSecret,
        },
      }
    );
    if (!resp.ok) return null;
    const data = await resp.json();
    const bars = data.bars;
    if (!bars || bars.length < 2) return null;

    const latest = bars[bars.length - 1];
    const prev = bars[bars.length - 2];
    const price = +latest.c.toFixed(2);
    const change = +(price - prev.c).toFixed(2);
    const changePct = +((change / prev.c) * 100).toFixed(2);
    const vwap = +(latest.vw || price).toFixed(2);
    const vol = latest.v || 0;

    // Calculate RSI from recent closes
    const closes = bars.map(b => b.c);
    const rsi = calcRSI(closes, 14);
    const atr = +(price * 0.015).toFixed(2);
    const macd = change > 0 ? 0.5 : -0.5;
    const volRatio = +(vol / 1000000).toFixed(2);
    const trend = changePct > 0.6 ? 'uptrend' : changePct < -0.6 ? 'downtrend' : 'sideways';

    return { ticker, price, change, changePct, rsi, vwap, vol, atr, macd, volRatio, trend };
  } catch (e) {
    console.error(`Market data error for ${ticker}:`, e.message);
    return null;
  }
}

function calcRSI(closes, period = 14) {
  if (closes.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) gains += d;
    else losses += Math.abs(d);
  }
  const rs = (gains / period) / (losses / period || 0.001);
  return +(100 - 100 / (1 + rs)).toFixed(1);
}

// ─── Regime detection ─────────────────────────────────────
function detectRegime(m) {
  if (m.volRatio > 1.5 && Math.abs(m.changePct) > 1.8)
    return { regime: 'volatile', strategy: 'Breakout' };
  if (m.trend !== 'sideways' && m.volRatio > 0.9 && Math.abs(m.changePct) > 0.5)
    return { regime: 'trending', strategy: 'Momentum' };
  return { regime: 'ranging', strategy: 'Mean Reversion' };
}

// ─── Memory context ───────────────────────────────────────
function buildMemoryContext() {
  if (!state.memories.length) return 'No trade history yet.';
  const recent = state.memories.slice(0, 8).map(m =>
    `[${m.won ? 'WIN' : 'LOSS'}] ${m.ticker} ${m.strategy} ${m.regime} RSI:${m.rsi} ${m.price > m.vwap ? 'aboveVWAP' : 'belowVWAP'} Conf:${m.conf}/10 PnL:${m.pnl >= 0 ? '+' : ''}$${Math.abs(m.pnl).toFixed(0)} Lesson:${m.lesson || 'none'}`
  ).join('\n');
  const stratPerf = Object.entries(state.stratStats)
    .filter(([, d]) => d.w + d.l > 0)
    .map(([s, d]) => `${s}:${Math.round(d.w / (d.w + d.l) * 100)}%WR(${d.w + d.l}t)`)
    .join(' | ');
  const topLessons = state.lessons.slice(0, 4).map(l => `• ${l.lesson}`).join('\n');
  return `TRADE MEMORY (${state.memories.length} trades):\n${recent}\nStrategy performance: ${stratPerf || 'none yet'}\n${state.lessons.length ? 'Lessons:\n' + topLessons : ''}`;
}

// ─── Claude API ───────────────────────────────────────────
async function callClaude(prompt, maxTokens = 800) {
  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CONFIG.anthropicKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: maxTokens,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    const data = await resp.json();
    if (!data?.content?.length) return null;
    return data.content.map(b => b.text || '').join('');
  } catch (e) {
    console.error('Claude API error:', e.message);
    return null;
  }
}

function buildTradePrompt(m, strategy, regime, equity) {
  const maxRiskAmt = equity * (CONFIG.maxRiskPct / 100);
  const shares = Math.max(1, Math.floor(maxRiskAmt / (m.atr || m.price * 0.015)));
  return `You are a professional day trader AI with expert knowledge and trade memory. Analyze and decide.

MARKET: ${m.ticker} $${m.price} (${m.changePct > 0 ? '+' : ''}${m.changePct}%) RSI:${m.rsi} VWAP:$${m.vwap}(${m.price > m.vwap ? 'ABOVE' : 'BELOW'}) VOL:${m.volRatio}x ATR:$${m.atr} MACD:${m.macd > 0 ? 'BULL' : 'BEAR'} TREND:${m.trend} REGIME:${regime.toUpperCase()} STRATEGY:${strategy}
ACCOUNT: equity $${equity.toFixed(0)} | max risk $${maxRiskAmt.toFixed(0)} | suggested shares: ${shares}

${buildMemoryContext()}

${EXPERT_KNOWLEDGE}

STRATEGY: ${strategy === 'Momentum' ? 'Buy>VWAP+RSI50-70+MACDbull+vol>1.2x. Short<VWAP+RSI30-50+MACDbear.' : strategy === 'Mean Reversion' ? 'Buy RSI<35+price<VWAP. Short RSI>68+price>VWAP. Target VWAP.' : 'Buy confirmed break vol>1.4x. Stop 1.5xATR. No chasing.'}
RISK: Never risk>$${maxRiskAmt.toFixed(0)}. Stop required. 1:2 RR minimum. If weak setup → HOLD.

Reply EXACTLY:
DECISION: BUY or SELL or HOLD
SHARES: ${shares}
ENTRY: $${m.price}
STOP: $[price]
TARGET: $[price]
CONFIDENCE: [1-10]
REASONING: [2-3 sentences]`;
}

function buildLearnPrompt(trade, won) {
  return `Trading AI reviewing trade outcome to improve.
TRADE: ${trade.action} ${trade.ticker} via ${trade.strategy} in ${trade.regime} regime
RSI:${trade.rsi} VWAP:${trade.price > trade.vwap ? 'above' : 'below'} VOL:${trade.volRatio}x Conf:${trade.conf}/10
OUTCOME: ${won ? 'WIN' : 'LOSS'} PnL:${trade.pnl >= 0 ? '+' : ''}$${Math.abs(trade.pnl).toFixed(2)}
Reply EXACTLY:
LESSON: [one actionable sentence]
PATTERN: [pattern in 8 words]
CONF_OK: yes or no
STRAT_FIT: good or poor`;
}

// ─── IQ calculation ───────────────────────────────────────
function calcIQ() {
  const n = state.trades.length;
  if (n < 3) return 50;
  const wr = state.wins / n;
  const memBonus = Math.min(20, state.memories.length * 2);
  let stratBonus = 0;
  Object.values(state.stratStats).forEach(s => {
    const t = s.w + s.l;
    if (t >= 3 && s.w / t > 0.55) stratBonus += 3;
  });
  return Math.max(10, Math.min(100,
    Math.round(50 + (wr - 0.5) * 40 + (state.totalPnl / n > 0 ? 10 : 0) + memBonus + Math.min(10, stratBonus))
  ));
}

// ─── Core trade loop ──────────────────────────────────────
async function analyzeTicker(ticker) {
  console.log(`\n🔍 Analyzing ${ticker}...`);

  // Get real market data
  const m = await getMarketData(ticker);
  if (!m) {
    console.log(`  ⚠ No market data for ${ticker}`);
    return null;
  }

  // Get account info
  let equity = 100000;
  try {
    const account = await getAccount();
    equity = parseFloat(account.equity);
  } catch (e) {
    console.error('  Account fetch failed:', e.message);
  }

  // Detect regime
  const r = detectRegime(m);
  console.log(`  Regime: ${r.regime} | Strategy: ${r.strategy} | Price: $${m.price} | RSI: ${m.rsi}`);

  // Call Claude
  const text = await callClaude(buildTradePrompt(m, r.strategy, r.regime, equity), 700);
  if (!text) {
    console.log(`  ⚠ No Claude response for ${ticker}`);
    return null;
  }

  // Parse decision
  const get = k => { const x = text.match(new RegExp(k + ':\\s*(.+)')); return x ? x[1].trim() : null; };
  const rawDecision = get('DECISION') || 'HOLD';
  const action = rawDecision.toUpperCase().includes('BUY') ? 'BUY'
    : rawDecision.toUpperCase().includes('SELL') ? 'SELL' : 'HOLD';
  const shares = parseInt(get('SHARES')) || 10;
  const entry = get('ENTRY') || '$' + m.price;
  const stop = get('STOP') || '—';
  const target = get('TARGET') || '—';
  const confidence = parseInt(get('CONFIDENCE')) || 5;
  const rm = text.match(/REASONING:\s*([\s\S]+?)(?:\n[A-Z_]+:|$)/);
  const reasoning = rm ? rm[1].trim() : '';

  console.log(`  Decision: ${action} | Confidence: ${confidence}/10 | Shares: ${shares}`);
  console.log(`  Reasoning: ${reasoning.slice(0, 100)}...`);

  return { action, shares, entry, stop, target, confidence, reasoning, market: m, regime: r };
}

async function executeTrade(decision) {
  const { action, shares, entry, stop, target, confidence, reasoning, market: m, regime: r } = decision;

  // Risk gates
  if (confidence < CONFIG.minConfidence) {
    console.log(`  ⚠ Confidence ${confidence} below minimum ${CONFIG.minConfidence} — skipping`);
    return;
  }
  if (state.dailyLoss >= CONFIG.dailyLossLimit) {
    console.log(`  🛑 Daily loss limit $${CONFIG.dailyLossLimit} reached — no more trades today`);
    await sendEmail(
      '🛑 APEX Trader — Daily Loss Limit Hit',
      `The agent has stopped trading for today.\n\nDaily loss limit: $${CONFIG.dailyLossLimit}\nLoss so far: $${state.dailyLoss.toFixed(2)}\n\nTrading will resume tomorrow morning.`
    );
    return;
  }

  // Check open positions
  let positions = [];
  try {
    positions = await getPositions();
  } catch (e) {}
  if (positions.length >= CONFIG.maxPositions) {
    console.log(`  ⚠ At max positions (${CONFIG.maxPositions}) — skipping`);
    return;
  }

  // Place order
  const side = action === 'BUY' ? 'buy' : 'sell';
  try {
    const order = await alpacaPost('/v2/orders', {
      symbol: m.ticker,
      qty: shares,
      side,
      type: 'market',
      time_in_force: 'day',
    });

    const tradeRecord = {
      id: order.id,
      time: new Date().toISOString(),
      ticker: m.ticker,
      action,
      shares,
      entry,
      stop,
      target,
      conf: confidence,
      strategy: r.strategy,
      regime: r.regime,
      rsi: m.rsi,
      vwap: m.vwap,
      price: m.price,
      volRatio: m.volRatio,
      trend: m.trend,
      reasoning,
      mode: CONFIG.alpacaMode,
    };
    state.trades.unshift(tradeRecord);

    console.log(`  ✅ Order placed: ${action} ${shares} shares ${m.ticker} | ID: ${order.id?.slice(0, 8)}`);

    // Send email alert
    await sendEmail(
      `${CONFIG.alpacaMode === 'live' ? '💰 LIVE' : '📄 PAPER'} ORDER — ${action} ${m.ticker}`,
      `${action} ${shares} shares of ${m.ticker}
Price: $${m.price}
Entry: ${entry} | Stop: ${stop} | Target: ${target}
Strategy: ${r.strategy} | Regime: ${r.regime}
Confidence: ${confidence}/10
Reasoning: ${reasoning}
Order ID: ${order.id?.slice(0, 12)}
Mode: ${CONFIG.alpacaMode.toUpperCase()}
Portfolio P&L: ${state.totalPnl >= 0 ? '+' : ''}$${state.totalPnl.toFixed(2)}
Agent IQ: ${state.agentIQ} | Memories: ${state.memories.length}`
    );

    // Learn from this setup (async, don't await)
    learnFromSetup(tradeRecord);

    saveState();

  } catch (e) {
    console.error(`  ❌ Order failed for ${m.ticker}:`, e.message);
    await sendEmail(
      `⚠ APEX Trader — Order Failed: ${m.ticker}`,
      `Failed to place ${action} order for ${m.ticker}\nError: ${e.message}\nThe agent will continue scanning other tickers.`
    );
  }
}

async function learnFromSetup(trade) {
  // Simulate outcome for learning (real P&L comes later when position closes)
  const won = Math.random() > 0.45; // Placeholder until real close data
  const text = await callClaude(buildLearnPrompt(trade, won), 250);
  if (!text) return;

  const get = k => { const x = text.match(new RegExp(k + ':\\s*(.+)')); return x ? x[1].trim() : null; };
  const lesson = get('LESSON') || 'Monitor similar setups.';
  const pattern = get('PATTERN') || '—';
  const confOk = get('CONF_OK') || 'yes';
  const stratFit = get('STRAT_FIT') || 'good';

  const memory = {
    ticker: trade.ticker, strategy: trade.strategy, regime: trade.regime,
    rsi: trade.rsi, vwap: trade.vwap, price: trade.price,
    volRatio: trade.volRatio, trend: trade.trend, conf: trade.conf,
    action: trade.action, pnl: won ? 150 : -80, won, lesson, pattern, confOk, stratFit,
    time: new Date().toLocaleTimeString(),
  };
  state.memories.unshift(memory);
  if (state.memories.length > 200) state.memories = state.memories.slice(0, 200);

  if (!won || confOk === 'no' || stratFit === 'poor') {
    state.lessons.unshift({ lesson, pattern, won, strategy: trade.strategy, time: memory.time });
    if (state.lessons.length > 50) state.lessons = state.lessons.slice(0, 50);
  }

  // Update confidence calibration
  const c = parseInt(trade.conf) || 5;
  const bi = c <= 4 ? 0 : c <= 6 ? 1 : c <= 8 ? 2 : 3;
  state.confBuckets[bi].s++;
  if (won) state.confBuckets[bi].w++;

  state.agentIQ = calcIQ();
  console.log(`  🧠 Learned: "${lesson.slice(0, 60)}..." | IQ: ${state.agentIQ}`);
  saveState();
}

// ─── Main scan loop ───────────────────────────────────────
async function runScanCycle() {
  if (!state.isRunning) return;

  checkDailyReset();

  // Check daily loss limit
  if (state.dailyLoss >= CONFIG.dailyLossLimit) {
    console.log('🛑 Daily loss limit reached — pausing until tomorrow');
    return;
  }

  console.log(`\n━━━ Scan cycle ${new Date().toLocaleTimeString()} ━━━`);

  // Shuffle watchlist for variety
  const shuffled = [...WATCHLIST].sort(() => Math.random() - 0.5);

  for (const ticker of shuffled) {
    if (!state.isRunning) break;

    const decision = await analyzeTicker(ticker);
    if (decision && decision.action !== 'HOLD') {
      await executeTrade(decision);
      // Small delay between trades
      await new Promise(r => setTimeout(r, 2000));
    }
  }

  state.lastScanTime = new Date().toISOString();
  console.log(`━━━ Cycle complete. IQ: ${state.agentIQ} | Trades: ${state.trades.length} | Memories: ${state.memories.length} ━━━\n`);
}

// ─── Morning scan (9:30 AM ET) ────────────────────────────
// Cron: '30 9 * * 1-5' = 9:30 on weekdays (adjust for your timezone offset)
cron.schedule('30 13 * * 1-5', async () => {
  // 13:30 UTC = 9:30 AM ET (UTC-4 during EDT)
  console.log('🌅 Market open scan triggered');
  await sendEmail(
    '🌅 APEX Trader — Market Open Scanner Running',
    `Good morning! Market just opened.\n\nThe agent is scanning ${WATCHLIST.length} stocks for today's best opportunities.\nIQ: ${state.agentIQ} | Memories: ${state.memories.length} | Lessons: ${state.lessons.length}`
  );
  await runScanCycle();
}, { timezone: 'America/New_York' });

// ─── Regular scan interval ────────────────────────────────
let scanIntervalTimer = null;

function startScanInterval() {
  if (scanIntervalTimer) clearInterval(scanIntervalTimer);
  scanIntervalTimer = setInterval(runScanCycle, CONFIG.scanIntervalMins * 60 * 1000);
  console.log(`⏱ Scan interval set: every ${CONFIG.scanIntervalMins} minutes`);
}

// ─── Daily P&L summary email (4:30 PM ET) ────────────────
cron.schedule('30 20 * * 1-5', async () => {
  // 20:30 UTC = 4:30 PM ET
  const n = state.trades.length;
  const wr = n ? Math.round(state.wins / n * 100) : 0;
  await sendEmail(
    `📊 APEX Trader — Daily Summary`,
    `Market close summary for ${new Date().toLocaleDateString()}

PERFORMANCE
Total P&L: ${state.totalPnl >= 0 ? '+' : ''}$${state.totalPnl.toFixed(2)}
Daily loss: $${state.dailyLoss.toFixed(2)} (limit: $${CONFIG.dailyLossLimit})
Win rate: ${wr}% (${state.wins}W / ${state.losses}L)
Total trades: ${n}

AGENT STATUS
IQ score: ${state.agentIQ}/100
Memories stored: ${state.memories.length}
Lessons learned: ${state.lessons.length}
Mode: ${CONFIG.alpacaMode.toUpperCase()}

${state.lessons.length > 0 ? 'LATEST LESSON:\n' + state.lessons[0].lesson : ''}

The agent will resume scanning at market open tomorrow.`
  );
}, { timezone: 'America/New_York' });

// ─── REST API (for dashboard to connect to) ───────────────
app.get('/status', (req, res) => {
  res.json({
    isRunning: state.isRunning,
    agentIQ: state.agentIQ,
    memories: state.memories.length,
    lessons: state.lessons.length,
    trades: state.trades.length,
    totalPnl: state.totalPnl,
    wins: state.wins,
    losses: state.losses,
    dailyLoss: state.dailyLoss,
    mode: CONFIG.alpacaMode,
    lastScanTime: state.lastScanTime,
  });
});

app.get('/trades', (req, res) => {
  res.json(state.trades.slice(0, 50));
});

app.get('/memories', (req, res) => {
  res.json(state.memories.slice(0, 50));
});

app.get('/lessons', (req, res) => {
  res.json(state.lessons.slice(0, 20));
});

app.post('/start', (req, res) => {
  state.isRunning = true;
  saveState();
  startScanInterval();
  runScanCycle(); // Run immediately
  console.log('▶ Agent started via API');
  sendEmail('▶ APEX Trader Started', `The trading agent has been started.\nMode: ${CONFIG.alpacaMode.toUpperCase()}\nScan interval: every ${CONFIG.scanIntervalMins} minutes`);
  res.json({ success: true, message: 'Agent started' });
});

app.post('/stop', (req, res) => {
  state.isRunning = false;
  if (scanIntervalTimer) { clearInterval(scanIntervalTimer); scanIntervalTimer = null; }
  saveState();
  console.log('⏹ Agent stopped via API');
  sendEmail('⏹ APEX Trader Stopped', `The trading agent has been stopped.\nFinal IQ: ${state.agentIQ}\nTotal trades: ${state.trades.length}\nP&L: ${state.totalPnl >= 0 ? '+' : ''}$${state.totalPnl.toFixed(2)}`);
  res.json({ success: true, message: 'Agent stopped' });
});

app.post('/scan-now', async (req, res) => {
  res.json({ success: true, message: 'Scan started' });
  await runScanCycle();
});

app.get('/positions', async (req, res) => {
  try {
    const positions = await getPositions();
    res.json(positions);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/positions', async (req, res) => {
  try {
    await fetch(ALPACA_BASE + '/v2/positions', {
      method: 'DELETE',
      headers: {
        'APCA-API-KEY-ID': CONFIG.alpacaKey,
        'APCA-API-SECRET-KEY': CONFIG.alpacaSecret,
      },
    });
    res.json({ success: true });
    sendEmail('⬛ All Positions Closed', 'All open positions have been closed via the dashboard.');
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Health check for Railway
app.get('/', (req, res) => {
  res.send(`APEX Trader Server running | Mode: ${CONFIG.alpacaMode} | IQ: ${state.agentIQ} | Running: ${state.isRunning}`);
});

// ─── Start server ─────────────────────────────────────────
app.listen(CONFIG.port, () => {
  console.log(`\n🚀 APEX Trader Server started on port ${CONFIG.port}`);
  console.log(`   Mode: ${CONFIG.alpacaMode.toUpperCase()}`);
  console.log(`   Scan interval: every ${CONFIG.scanIntervalMins} minutes`);
  console.log(`   Min confidence: ${CONFIG.minConfidence}/10`);
  console.log(`   Daily loss limit: $${CONFIG.dailyLossLimit}`);
  console.log(`   Max positions: ${CONFIG.maxPositions}`);

  loadState();
  console.log(`\n   POST /start  → start the agent`);
  console.log(`   POST /stop   → stop the agent`);
  console.log(`   GET  /status → check status\n`);

  // Auto-start if was running before restart
  if (state.isRunning) {
    console.log('↺ Auto-resuming from previous state...');
    startScanInterval();
  }
});
