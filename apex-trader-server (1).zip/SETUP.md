# APEX Trader Server — Setup Guide

## What this does
Runs your trading agent 24/7 in the cloud — completely independent of your browser.
Scans stocks, analyzes with Claude, places Alpaca orders, emails you every trade.

---

## Step 1 — Get your API keys

### Anthropic (Claude)
1. Go to console.anthropic.com
2. API Keys → Create Key
3. Copy it — this is your ANTHROPIC_API_KEY

### Alpaca (trading)
1. Go to alpaca.markets → create account
2. For paper trading: click "Paper Trading" → API Keys → Generate
3. Copy both Key ID and Secret Key
4. For live trading later: same steps under "Live Trading"

### Gmail app password (for email alerts)
1. Go to myaccount.google.com → Security
2. Turn on 2-Step Verification (required)
3. Search "App passwords" → Select app: Mail → Generate
4. Copy the 16-character password (not your regular Gmail password)

---

## Step 2 — Deploy to Railway (free tier, no credit card)

1. Go to railway.app → Sign up with GitHub (free)
2. Click "New Project" → "Deploy from GitHub repo"
3. Upload this folder to a new GitHub repo first:
   - Go to github.com → New repository → name it "apex-trader"
   - Upload all files in this folder
   - Come back to Railway → select that repo
4. Railway will auto-detect Node.js and deploy

---

## Step 3 — Set environment variables in Railway

In your Railway project → click your service → Variables tab → add each one:

```
ANTHROPIC_API_KEY     = your_anthropic_key
ALPACA_API_KEY        = your_alpaca_key
ALPACA_API_SECRET     = your_alpaca_secret
ALPACA_MODE           = paper
EMAIL_FROM            = your_gmail@gmail.com
EMAIL_PASSWORD        = your_16_char_app_password
EMAIL_TO              = your_email@gmail.com
MAX_RISK_PER_TRADE    = 1.5
DAILY_LOSS_LIMIT      = 500
MAX_OPEN_POSITIONS    = 3
MIN_CONFIDENCE        = 6
SCAN_INTERVAL_MINUTES = 5
PORT                  = 3000
```

---

## Step 4 — Start the agent

Once deployed, Railway gives you a URL like:
https://apex-trader-production.up.railway.app

Start the agent:
  POST https://your-url.railway.app/start

You can do this from your browser using a tool like Postman, or just paste this in your browser console:
  fetch('https://your-url/start', {method:'POST'})

Or add the server URL to your APEX dashboard to control it from the UI.

---

## API endpoints

| Endpoint | Method | What it does |
|----------|--------|--------------|
| /        | GET    | Health check |
| /status  | GET    | Full status, IQ, P&L, trade count |
| /start   | POST   | Start the agent |
| /stop    | POST   | Stop the agent |
| /scan-now | POST  | Run one scan immediately |
| /trades  | GET    | Last 50 trades |
| /memories | GET   | Last 50 memories |
| /lessons | GET    | Last 20 lessons |
| /positions | GET  | Current open positions |
| /positions | DELETE | Close all positions |

---

## Email alerts you'll receive

- ▶ Agent started
- 📄 Every paper trade (or 💰 live trade)
- ⚠ Order failures
- 🛑 Daily loss limit hit
- 📊 Daily summary at 4:30 PM ET
- 🌅 Market open notification at 9:30 AM ET
- 📅 New trading day reset

---

## Switching to live trading

1. Get live Alpaca API keys (separate from paper keys)
2. In Railway variables → change:
   - ALPACA_API_KEY = your live key
   - ALPACA_API_SECRET = your live secret
   - ALPACA_MODE = live
3. Redeploy

⚠ Only do this after consistent paper trading success (55%+ win rate over 50+ trades)

---

## Costs

- Railway: Free tier = $5 credit/month, enough for 24/7 running. Paid = $5/month after that.
- Anthropic: ~$0.01-0.03 per trade analysis. 100 trades/day ≈ $1-3/day.
- Alpaca: Free (paper and live basic account)
- Gmail: Free

Total: ~$5-8/month to run 24/7
